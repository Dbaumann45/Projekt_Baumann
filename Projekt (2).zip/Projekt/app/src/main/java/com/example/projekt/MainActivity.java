package com.example.projekt;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    String[] appPermissions = {
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.SEND_SMS
    };


    private static final int RQ_PREFERENCES = 100;
    private static final int PERMISSIONS_REQUEST_CODE = 1240;


    private SharedPreferences prefs;



    ListView list;
    static ArrayList<String> IDs = new ArrayList<>();
    static ArrayList mobileArray;


    static ArrayList<String> names = new ArrayList<>();
    static ArrayList<String> numbers = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gruppen);

        //noinspection deprecation
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        if (!hasPermissions(this, appPermissions)) {
            ActivityCompat.requestPermissions(this, appPermissions, PERMISSIONS_REQUEST_CODE);
        }
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED) {
            mobileArray = getAllContacts();
        }
        list = findViewById(R.id.gruppen);
        ArrayAdapter adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, mobileArray);
        list.setAdapter(adapter);
        registerForContextMenu(list);





    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_bar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.neue_Kontakte:
                setContentView(R.layout.kontakt_ersteller);


                break;
            case R.id.sms_schreiben:
                setContentView(R.layout.sms_schreiber);

                break;
            case R.id.preferences:
                Intent intent = new Intent(this, MainActivity.class);
                startActivityForResult(intent, RQ_PREFERENCES);

                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        int viewId = v.getId();
        if(viewId == R.id.contextmenu || viewId == R.id.gruppen)
        {
            getMenuInflater().inflate(R.menu.kontakt_listmenu, menu);
        }
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item .getMenuInfo();
        int positionSelected = menuInfo.position;

        if (item.getItemId() == R.id.contactInfo_show) {

            showContactInfo(positionSelected);
            return true;
        }
        if (item.getItemId() == R.id.contact_change) {
            Toast.makeText(this, "Kontakt ändern", Toast.LENGTH_LONG).show();

            setContentView(R.layout.kontakt_bearbeiter);

            EditText contactName = findViewById(R.id.change_name);
            EditText contactNumber = findViewById(R.id.change_number);

            String changeName = names.get(positionSelected);
            String changeNumber = numbers.get(positionSelected);

            contactName.setText(changeName);
            contactNumber.setText(changeNumber);

            return true;
        }
            if (item.getItemId() == R.id.contactChat_show) {

                setContentView(R.layout.chat);

                return true;
            }
            return super.onContextItemSelected(item);
        }


    public static boolean hasPermissions(Context context, String... permissions)
    {
        if(context != null && permissions != null)
        {
            for(String permission : permissions)
            {
                if(ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED)
                {
                    return false;
                }
            }
        }
        return true;
    }

    private ArrayList getAllContacts() {
        ArrayList<String> nameList = new ArrayList<>();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);
        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                nameList.add(name);
                IDs.add(id);
                names.add(name);
                if (cur.getInt(cur.getColumnIndex( ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
                        numbers.add(phoneNo);

                    }
                    pCur.close();
                }

            }
        }
        if (cur != null) {
            cur.close();
        }
        return nameList;
    }


    @Override
    public void onClick(View view) {


        switch(view.getId())
        {


            case R.id.kontakt_erstellen:

                EditText name = findViewById(R.id.new_name);
                String name_enter = name.getText().toString();
                EditText number = findViewById(R.id.new_number);
                String number_enter = number.getText().toString();
                EditText group = findViewById(R.id.new_group);
                String group_enter = group.getText().toString();

                Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                intent.putExtra(ContactsContract.Intents.Insert.PHONE, number_enter);
                intent.putExtra(ContactsContract.Intents.Insert.NAME, name_enter);
                if(!group_enter.equals(""))
                {
                    intent.putExtra(ContactsContract.Intents.Insert.COMPANY, group_enter);
                }

                startActivity(intent);

                IDs.add(String.valueOf(IDs.size()));
                names.add(name_enter);
                numbers.add(number_enter);
                name.setText("");
                number.setText("");
                group.setText("");
                break;

            case R.id.kontakt_bearbeiten  :

                EditText contactName = findViewById(R.id.change_name);
                EditText contactNumber = findViewById(R.id.change_number);

                String nameChanged = String.valueOf(contactName);
                String numberChanged = String.valueOf(contactNumber);



                break;

            case R.id.adressaten_wählen:

                final EditText message = findViewById(R.id.nachricht);

                final String sms = String.valueOf(message.getText());

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Kontakte zum Senden wählen");

                final ArrayList<String> numbers_for_sms = new ArrayList<>();
                String[] contacts = new String[names.size()];
                final boolean[] checkedItems = new boolean[names.size()];
                for(int j = 0; j < names.size(); j++)
                {
                    contacts[j] = names.get(j);
                    checkedItems[j] = false;
                }

                builder.setMultiChoiceItems(contacts, null, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {

                        if(isChecked)
                        {
                            checkedItems[which] = true;
                        }
                    }
                });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        for(int t = 0; t < names.size(); t++)
                        {
                            if(checkedItems[t] == true)
                            {
                                numbers_for_sms.add(numbers.get(t));
                            }
                        }

                        for(int h = 0; h < numbers_for_sms.size(); h++)
                        {
                            sendSMS(numbers_for_sms.get(h),sms);
                        }
                        message.setText("");
                        Toast.makeText(getApplicationContext(), "Nachricht gesendet", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("Cancel", null);
                AlertDialog dialog = builder.create();
                dialog.show();

                break;
        }

    }



    private void showContactInfo(int ID)
    {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

        builder.setTitle(names.get(ID));
        builder.setMessage("ID: " + (ID + 1) + "\n" + "Nummer: " + numbers.get(ID));
        builder.setNegativeButton("Zurück", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });
        builder.show();

    }

    private void sendSMS(String phoneNo, String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNo, null, msg, null, null);

        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(),ex.getMessage().toString(),
                    Toast.LENGTH_SHORT).show();
            ex.printStackTrace();
        }
    }


    







};


